(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/base/information/index"],{"17c4":function(n,t,e){},"6f30":function(n,t,e){"use strict";e.r(t);var u=e("f306"),a=e("b07a");for(var r in a)"default"!==r&&function(n){e.d(t,n,function(){return a[n]})}(r);e("da1e");var f=e("2877"),o=Object(f["a"])(a["default"],u["a"],u["b"],!1,null,null,null);t["default"]=o.exports},b07a:function(n,t,e){"use strict";e.r(t);var u=e("bfe5"),a=e.n(u);for(var r in u)"default"!==r&&function(n){e.d(t,n,function(){return u[n]})}(r);t["default"]=a.a},bfe5:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={props:{iData:{type:Object,default:function(){return{}}}},data:function(){return{}}};t.default=u},da1e:function(n,t,e){"use strict";var u=e("17c4"),a=e.n(u);a.a},f306:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return a})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/base/information/index-create-component',
    {
        'components/common/base/information/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("6f30"))
        })
    },
    [['components/common/base/information/index-create-component']]
]);                
