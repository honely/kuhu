(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/base/notice/index"],{1332:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return a})},"51bd":function(n,t,e){"use strict";var u=e("7052"),a=e.n(u);a.a},7052:function(n,t,e){},"7d2f":function(n,t,e){"use strict";e.r(t);var u=e("1332"),a=e("a4ae");for(var c in a)"default"!==c&&function(n){e.d(t,n,function(){return a[n]})}(c);e("51bd");var r=e("2877"),i=Object(r["a"])(a["default"],u["a"],u["b"],!1,null,null,null);t["default"]=i.exports},a4ae:function(n,t,e){"use strict";e.r(t);var u=e("a5cc"),a=e.n(u);for(var c in u)"default"!==c&&function(n){e.d(t,n,function(){return u[n]})}(c);t["default"]=a.a},a5cc:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={props:{iData:{type:Object,defalut:function(){return{}}}},data:function(){return{notices:["时政新闻眼丨习近平说，这件事要做好“长期作战”的思想准备","三鹿受害少年患肾病用无限极产品当药品，后确诊尿毒症去世","新年刚过不到20天 中国海警三次巡航钓鱼岛领海"]}},methods:{linkListener:function(n){this.config.onLinkListener(n)}}};t.default=u}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/base/notice/index-create-component',
    {
        'components/common/base/notice/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("7d2f"))
        })
    },
    [['components/common/base/notice/index-create-component']]
]);                
