(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/base/rich/index"],{"0759":function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return r})},"1b52":function(n,t,e){},"1e74":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={props:{rDatas:{type:Array,default:function(){return[]}}},data:function(){return{}}};t.default=u},5308:function(n,t,e){"use strict";e.r(t);var u=e("0759"),r=e("66a7");for(var a in r)"default"!==a&&function(n){e.d(t,n,function(){return r[n]})}(a);e("ff10");var f=e("2877"),o=Object(f["a"])(r["default"],u["a"],u["b"],!1,null,null,null);t["default"]=o.exports},"66a7":function(n,t,e){"use strict";e.r(t);var u=e("1e74"),r=e.n(u);for(var a in u)"default"!==a&&function(n){e.d(t,n,function(){return u[n]})}(a);t["default"]=r.a},ff10:function(n,t,e){"use strict";var u=e("1b52"),r=e.n(u);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/base/rich/index-create-component',
    {
        'components/common/base/rich/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("5308"))
        })
    },
    [['components/common/base/rich/index-create-component']]
]);                
