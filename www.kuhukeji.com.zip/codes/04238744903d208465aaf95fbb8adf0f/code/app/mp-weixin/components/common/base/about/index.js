(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/base/about/index"],{"098d":function(t,n,u){"use strict";u.r(n);var e=u("f7b9"),a=u("ac10");for(var r in a)"default"!==r&&function(t){u.d(n,t,function(){return a[t]})}(r);u("19d8");var c=u("2877"),o=Object(c["a"])(a["default"],e["a"],e["b"],!1,null,null,null);n["default"]=o.exports},"19d8":function(t,n,u){"use strict";var e=u("dd49"),a=u.n(e);a.a},ac10:function(t,n,u){"use strict";u.r(n);var e=u("b0cb"),a=u.n(e);for(var r in e)"default"!==r&&function(t){u.d(n,t,function(){return e[t]})}(r);n["default"]=a.a},b0cb:function(t,n,u){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={props:{aData:{type:Object,defalut:function(){return{}}}},data:function(){return{}}};n.default=e},dd49:function(t,n,u){},f7b9:function(t,n,u){"use strict";var e=function(){var t=this,n=t.$createElement;t._self._c},a=[];u.d(n,"a",function(){return e}),u.d(n,"b",function(){return a})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/base/about/index-create-component',
    {
        'components/common/base/about/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("098d"))
        })
    },
    [['components/common/base/about/index-create-component']]
]);                
