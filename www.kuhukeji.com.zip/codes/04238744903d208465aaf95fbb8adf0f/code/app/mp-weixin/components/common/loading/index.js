(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/loading/index"],{"0fed":function(t,n,e){"use strict";var a=e("19da"),u=e.n(a);u.a},"19da":function(t,n,e){},"500d":function(t,n,e){"use strict";e.r(n);var a=e("6761"),u=e.n(a);for(var o in a)"default"!==o&&function(t){e.d(n,t,function(){return a[t]})}(o);n["default"]=u.a},"5b66":function(t,n,e){"use strict";e.r(n);var a=e("8bbd"),u=e("500d");for(var o in u)"default"!==o&&function(t){e.d(n,t,function(){return u[t]})}(o);e("0fed");var r=e("2877"),i=Object(r["a"])(u["default"],a["a"],a["b"],!1,null,null,null);n["default"]=i.exports},6761:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=u(e("e217"));function u(t){return t&&t.__esModule?t:{default:t}}var o={props:{loading:{type:Object,default:function(){return{}}}},data:function(){return{topHeight:0,baseUrl:""}},created:function(){this.$data.baseUrl=a.default.hostUrl+"/static/uimage/wanneng","h5"==this.config.device?this.$data.topHeight=44:this.$data.topHeight=0},methods:{onRefreshPage:function(t){}}};n.default=o},"8bbd":function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/loading/index-create-component',
    {
        'components/common/loading/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("5b66"))
        })
    },
    [['components/common/loading/index-create-component']]
]);                
