(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/base/business/news"],{1359:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={props:{iData:{type:Object,defalut:function(){return{}}},sData:{type:Array,defalut:function(){return[]}}},data:function(){return{}},onLoad:function(){},methods:{linkListener:function(n){this.config.onLinkListener(n)}}};t.default=u},"51dd":function(n,t,e){"use strict";var u=e("f8a2"),a=e.n(u);a.a},5850:function(n,t,e){"use strict";e.r(t);var u=e("e825"),a=e("adb0");for(var r in a)"default"!==r&&function(n){e.d(t,n,function(){return a[n]})}(r);e("51dd");var o=e("2877"),i=Object(o["a"])(a["default"],u["a"],u["b"],!1,null,null,null);t["default"]=i.exports},adb0:function(n,t,e){"use strict";e.r(t);var u=e("1359"),a=e.n(u);for(var r in u)"default"!==r&&function(n){e.d(t,n,function(){return u[n]})}(r);t["default"]=a.a},e825:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return a})},f8a2:function(n,t,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/base/business/news-create-component',
    {
        'components/common/base/business/news-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("5850"))
        })
    },
    [['components/common/base/business/news-create-component']]
]);                
