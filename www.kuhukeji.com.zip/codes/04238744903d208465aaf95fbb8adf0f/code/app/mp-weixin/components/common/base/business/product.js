(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/base/business/product"],{"0f05":function(n,t,e){},"943f":function(n,t,e){"use strict";var u=e("0f05"),a=e.n(u);a.a},b3fb:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return a})},c6b1:function(n,t,e){"use strict";e.r(t);var u=e("e7bc"),a=e.n(u);for(var o in u)"default"!==o&&function(n){e.d(t,n,function(){return u[n]})}(o);t["default"]=a.a},e7bc:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={props:{iData:{type:Object,defalut:function(){return{}}},sData:{type:Array,defalut:function(){return[]}}},data:function(){return{}},onLoad:function(){},methods:{_Init:function(n){console.log("aadasda")},linkListener:function(n){this.config.onLinkListener(n)}}};t.default=u},fdad:function(n,t,e){"use strict";e.r(t);var u=e("b3fb"),a=e("c6b1");for(var o in a)"default"!==o&&function(n){e.d(t,n,function(){return a[n]})}(o);e("943f");var r=e("2877"),c=Object(r["a"])(a["default"],u["a"],u["b"],!1,null,null,null);t["default"]=c.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/base/business/product-create-component',
    {
        'components/common/base/business/product-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("fdad"))
        })
    },
    [['components/common/base/business/product-create-component']]
]);                
