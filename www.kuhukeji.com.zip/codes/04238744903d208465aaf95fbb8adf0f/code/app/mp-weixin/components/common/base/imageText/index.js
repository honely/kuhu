(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/common/base/imageText/index"],{"271f":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={props:{iData:{type:Object,defalut:function(){return{}}}},data:function(){return{}},methods:{linkListener:function(n){this.config.onLinkListener(n)}}};t.default=u},"373d":function(n,t,e){},"6f14":function(n,t,e){"use strict";var u=e("373d"),r=e.n(u);r.a},"96aa":function(n,t,e){"use strict";e.r(t);var u=e("ee53"),r=e("db9e");for(var a in r)"default"!==a&&function(n){e.d(t,n,function(){return r[n]})}(a);e("6f14");var i=e("2877"),o=Object(i["a"])(r["default"],u["a"],u["b"],!1,null,null,null);t["default"]=o.exports},db9e:function(n,t,e){"use strict";e.r(t);var u=e("271f"),r=e.n(u);for(var a in u)"default"!==a&&function(n){e.d(t,n,function(){return u[n]})}(a);t["default"]=r.a},ee53:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return r})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/common/base/imageText/index-create-component',
    {
        'components/common/base/imageText/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("96aa"))
        })
    },
    [['components/common/base/imageText/index-create-component']]
]);                
