<?php

namespace app\web\controller;
use app\web\controller\Common;

class Woyaou extends  Common{
    
    
    public function index(){
        
       $this->error('我们正在很努力的加载页面');
    }
}
