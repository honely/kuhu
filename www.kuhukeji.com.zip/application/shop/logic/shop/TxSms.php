<?php
namespace app\shop\logic\shop;

class TxSms {

    /**
     * 腾讯云短信
     */

    static public function checkCode($mobile,$code){
        return true;
    }


}
