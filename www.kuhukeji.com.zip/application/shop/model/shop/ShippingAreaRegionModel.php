<?php
namespace app\shop\model\shop;
use app\shop\model\CommonModel;

class ShippingAreaRegionModel extends CommonModel{
    protected $pk = 'shipping_area_id';
    protected $name = 'app_shop_area_region';
}
