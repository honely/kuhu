<?php
namespace app\shop\model\shop;
use app\shop\model\CommonModel;

class SpecItemModel extends CommonModel
{
    protected $pk = 'item_id';
    protected $name = 'app_shop_spec_item';




}
