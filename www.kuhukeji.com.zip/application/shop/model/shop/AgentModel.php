<?php

namespace app\shop\model\shop;

use app\shop\model\CommonModel;

class AgentModel extends CommonModel
{
    protected $pk = 'address_id';
    protected $name = 'app_shop_user_address';




}
