<?php

namespace app\shop\model\shop;

use app\shop\model\CommonModel;

class OrderGoodsModel extends CommonModel{
    protected $pk = 'rec_id';
    protected $name = 'app_shop_order_goods';








}
