<?php

namespace app\shop\model\shop;

use app\shop\model\CommonModel;

//推广员的类  计算分佣等各方面统一入口类

class UserOpenIdModel extends CommonModel
{
    protected $pk = 'open_user_id';
    protected $name = 'app_shop_user_open_id';



}
