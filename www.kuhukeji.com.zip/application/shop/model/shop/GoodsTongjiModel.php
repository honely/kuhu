<?php

namespace app\shop\model\shop;

use app\shop\model\CommonModel;

class GoodsTongjiModel extends CommonModel
{
    protected $pk = 'log_id';
    protected $name = 'app_shop_goods_tongji';
    protected $insert = ['add_time', 'add_ip'];





}
