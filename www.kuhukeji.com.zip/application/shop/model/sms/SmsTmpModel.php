<?php
/**
*作者：baototo.com 尤哥
*/
namespace app\shop\model\sms;
use app\shop\model\CommonModel;

class SmsTmpModel extends CommonModel{
    protected $pk       = 'k';
    protected $name    = 'sms_tmp';

}
