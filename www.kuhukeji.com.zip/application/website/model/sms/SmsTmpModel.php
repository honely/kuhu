<?php
/**
*作者：baototo.com 尤哥
*/
namespace app\website\model\sms;
use app\website\model\CommonModel;

class SmsTmpModel extends CommonModel{
    protected $pk       = 'id';
    protected $name    = 'sms_tmp';

}
