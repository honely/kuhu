<?php
namespace app\website\model\website;

use app\website\model\CommonModel;

class AboutModel extends CommonModel
{
    protected $pk = 'app_id';
    protected $name = 'app_website_about';


}
