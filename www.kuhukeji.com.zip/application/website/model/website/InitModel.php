<?php
namespace app\website\model\website;

use app\website\model\CommonModel;

class InitModel extends CommonModel
{
    protected $pk = 'app_id';
    protected $name = 'app_website_init';

}
