<?php
//命名请 与 statusvalue 命名保持一致
//使用函数 getMenan();
return [
    //短信类型
    'sms_tmp_type' => [
        'zcdx' => 0,
        'yxdx' => 1,
        'jrdx' => 2,
    ],
    'shop_goods_tongji_type' => [
        'sc' => 1,
        'kj' => 2,
        'pt' => 3,
        'qg' => 4,
    ],
];
