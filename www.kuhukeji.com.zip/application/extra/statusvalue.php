<?php
//命名请 与 statuskey 命名保持一致
//使用函数 getMenan();
return [
    'template_type' => [
        1 => '限免',
        2 => '免费',
        3 => '收费',
    ],
    //短信类型
    'sms_tmp_type' => [
        0 => '注册短信',
        1 => '通知短信',
        2 => '营销短信',
    ],

];

