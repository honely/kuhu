<?php
return [
    1 => 'h5',
    2 => 'weixin',
    3 => 'ali',
    4 => 'baidu',
    5 => 'toutiao',
];