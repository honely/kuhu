<?php
return [
    'admin' => 'fbc690d93fc66d75191a42449baadbbe',
    'app'   => '286ecc7bd5ba0082739646fb9e89d3af',
    'api'   => '9e550c1bcfc67cdcf920b6b6a44d433d'
];
