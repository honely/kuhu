<?php
namespace app\admin\controller\resource;

use app\admin\controller\Common;
use think\Controller;

class Index extends Common
{

}
