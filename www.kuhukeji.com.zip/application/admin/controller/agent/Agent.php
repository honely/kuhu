<?php
namespace app\admin\controller\agent;
use app\admin\controller\Common;

class Agent  extends Common{

    public function index() {

    }



}
