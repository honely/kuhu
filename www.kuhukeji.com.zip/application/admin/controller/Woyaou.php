<?php

namespace app\admin\controller;
use think\Controller;
class Woyaou extends  Controller{
    
    
    public function index(){
        
       $this->error('我们正在很努力的加载页面');
    }
}
