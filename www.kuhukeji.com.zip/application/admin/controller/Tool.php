<?php

namespace app\admin\controller;

use app\common\library\make\MakeController;
use app\common\library\make\MakeCore;
use app\common\library\make\MakeModel;
use think\Controller;
use app\common\model\admin\AdminModel;

class Tool extends Controller
{

    public function index(){
        die("1");
    }

    public function makController() {
        $A = new AdminModel();
    }

    public function makModel()
    {

    }










}
