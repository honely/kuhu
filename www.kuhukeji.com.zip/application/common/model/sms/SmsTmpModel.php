<?php
/**
*作者：baototo.com 尤哥
*/
namespace app\common\model\sms;
use app\common\model\CommonModel;

class SmsTmpModel extends CommonModel{
    protected $pk       = 'k';
    protected $name    = 'sms_tmp';

}