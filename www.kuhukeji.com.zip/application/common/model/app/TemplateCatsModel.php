<?php
namespace app\common\model\app;
use app\common\model\CommonModel;

class TemplateCatsModel extends CommonModel
{
    protected $pk = 'cat_id';
    protected $name = 'app_template_cat';


   


}
