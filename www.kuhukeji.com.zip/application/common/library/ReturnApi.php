<?php
namespace app\common\library;

class ReturnApi {


    public function error(){
        echo "我是error";
    }


}
